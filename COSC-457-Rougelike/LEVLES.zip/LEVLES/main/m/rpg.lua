local rpg = {}

rpg.PHYSICAL = hash("PHYSICAL")
rpg.MAGIC = hash("MAGIC")
rpg.KNOCKBACK = hash("KNOCKBACK")

return rpg