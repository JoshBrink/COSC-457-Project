local signal = require "ludobits.m.signal"

local M = {}

M.TARGET_ID = signal.create("target_id")


	
return M