embedded_components {
  id: "background"
  type: "sprite"
  data: "tile_set: \"/assets/rgba/tiles.atlas\"\n"
  "default_animation: \"stoneblock6_A\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "blend_mode: BLEND_MODE_ALPHA\n"
  ""
  position {
    x: 0.0
    y: 24.0
    z: 0.0
  }
  rotation {
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
  }
}
embedded_components {
  id: "background1"
  type: "sprite"
  data: "tile_set: \"/assets/rgba/tiles.atlas\"\n"
  "default_animation: \"stoneblock6_B\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "blend_mode: BLEND_MODE_ALPHA\n"
  ""
  position {
    x: 0.0
    y: 79.0
    z: -9.0
  }
  rotation {
    x: -0.17364818
    y: 0.0
    z: 0.0
    w: 0.9848077
  }
}
