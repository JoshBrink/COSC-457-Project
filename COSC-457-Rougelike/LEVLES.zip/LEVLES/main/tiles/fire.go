embedded_components {
  id: "sprite"
  type: "sprite"
  data: "tile_set: \"/assets/rgba/tiles.atlas\"\n"
  "default_animation: \"fire\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "blend_mode: BLEND_MODE_ADD\n"
  ""
  position {
    x: 0.0
    y: 59.0
    z: 0.0
  }
  rotation {
    x: 0.0
    y: 0.0
    z: 0.0
    w: 1.0
  }
}
